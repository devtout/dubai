package br.com.camilolopes.classes;

public class StoreMatrix {
	private String name; 
	private  Address; 
}
